# Apache Ozone Helm Chart

Helm chart для развертывания распределенного объектного хранилища [Apache Ozone](https://ozone.apache.org) в Kubernetes/OpenShift.

## Компоненты

- **Ozone Manager (OM)** - менеджер метаданных (StatefulSet, 3 реплики)
- **Storage Container Manager (SCM)** - менеджер контейнеров (StatefulSet, 3 реплики)
- **DataNode** - хранение данных (StatefulSet, 3+ реплик)
- **Recon** - мониторинг и аналитика (StatefulSet, 1 реплика + OpenShift Route)
- **S3 Gateway** - S3-совместимый API (Deployment, 1+ реплик + OpenShift Route)
- **CLI** - CLI компонент для доступа к api ozone

## Установка

```bash
# Создание namespace
kubectl create namespace ozone

# Базовая установка
helm install ozone . --namespace ozone

# Установка с дев-настройками
helm install ozone . \
  --namespace ozone \
  --values values.yaml \
  --values values-dev.yaml
